document.addEventListener('unit_loaded', (e)=>{
	
	if(window.hasOwnProperty('wplms_course_data') && window.wplms_course_data.hasOwnProperty('dynamic_scripts') && window.wplms_course_data.dynamic_scripts && window.wplms_course_data.dynamic_scripts.length){
		window.wplms_course_data.dynamic_scripts.map(function(_script,i){
			if(document.getElementById(_script.id)){
				document.getElementById(_script.id).remove();
			}	
		    const script = document.createElement("script");
		    script.src =_script.src;
		    script.setAttribute("id", _script.id);
			document.body.appendChild(script);
		});
		
	}
	

	if(typeof elementorFrontend==='object' && Object.keys(elementorFrontend).length && typeof elementorFrontend.init !=='undefined'){
		elementorFrontend.init();
	}
	if(typeof elementorProFrontend==='object' && Object.keys(elementorProFrontend).length && typeof elementorProFrontend.init !=='undefined'){
		elementorProFrontend.init();
	}
   	
	checkiframeheights();
	
});
window.addEventListener('resize',checkiframeheights);
function checkiframeheights(){
	
	let iframes = document.querySelectorAll('.wplms_iframe_wrapper iframe');
	for(let i=0;i<iframes.length;i++){
	    let iframe = iframes[i];
	    iframe.setAttribute('style','height:'+iframe.contentWindow.document.querySelector('html').scrollHeight+'px;width:100%;');
	    document.querySelector('iframe').contentWindow.addEventListener('load',function(){iframe.setAttribute('style','height:'+iframe.contentWindow.document.querySelector('html').scrollHeight+'px;width:100%;');});

	    

	}
}