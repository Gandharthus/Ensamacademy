/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/singlecourse/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./_sass/main.scss":
/*!*************************!*\
  !*** ./_sass/main.scss ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("// extracted by mini-css-extract-plugin\n\n//# sourceURL=webpack:///./_sass/main.scss?");

/***/ }),

/***/ "./src/singlecourse/course.js":
/*!************************************!*\
  !*** ./src/singlecourse/course.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\nconst {\n  createElement,\n  useState,\n  useEffect,\n  Fragment,\n  render\n} = wp.element;\nconst {\n  dispatch,\n  select\n} = wp.data;\n\nconst Course = props => {\n  const [showCourse, setshowCourse] = useState(true);\n  const [isLoading, setIsLoading] = useState(true);\n  const [course, setCourse] = useState(null);\n  useEffect(() => {\n    setIsLoading(true);\n    fetch(`${window.wplms_course_data.api_url}/course/singlecourse?client_id=${window.wplms_course_data.client_id}`, {\n      method: 'post',\n      body: JSON.stringify({\n        id: props.id,\n        token: select('vibebp').getToken()\n      })\n    }).then(res => res.json()).then(data => {\n      setCourse(data);\n      setIsLoading(false);\n    });\n    setshowCourse(true);\n  }, [props.id]);\n  return showCourse ? createElement(\"div\", {\n    className: \"single_item_popup\"\n  }, createElement(\"div\", {\n    className: \"header\"\n  }, createElement(\"span\", null), createElement(\"span\", {\n    className: \"button small\",\n    onClick: () => {\n      setshowCourse(false);\n    }\n  }, createElement(\"span\", {\n    className: \"vicon vicon-close\"\n  }), window.vibebp.translations.close)), isLoading ? createElement(\"div\", {\n    class: \"lds-ellipsis\"\n  }, createElement(\"div\", null), createElement(\"div\", null), createElement(\"div\", null), createElement(\"div\", null)) : createElement(Fragment, null, course.length ? createElement(\"div\", {\n    className: \"\",\n    dangerouslySetInnerHTML: {\n      __html: course\n    }\n  }) : '')) : '';\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (Course);\n\n//# sourceURL=webpack:///./src/singlecourse/course.js?");

/***/ }),

/***/ "./src/singlecourse/index.js":
/*!***********************************!*\
  !*** ./src/singlecourse/index.js ***!
  \***********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _course_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./course.js */ \"./src/singlecourse/course.js\");\n/* harmony import */ var _sass_main_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../_sass/main.scss */ \"./_sass/main.scss\");\n/* harmony import */ var _sass_main_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sass_main_scss__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst {\n  createElement,\n  useState,\n  useEffect,\n  Fragment,\n  render\n} = wp.element;\nconst {\n  dispatch,\n  select\n} = wp.data;\ndocument.addEventListener('course_card_clicked', e => {\n  e.detail.original_event.preventDefault();\n  console.log(e);\n\n  if (document.getElementById('single_item_popup')) {\n    document.getElementById('single_item_popup').remove();\n  }\n\n  let dd = document.createElement('div');\n  dd.innerHTML = '';\n  dd.id = 'single_item_popup';\n  document.body.appendChild(dd);\n\n  if (e.detail.hasOwnProperty('id')) {\n    render(createElement(_course_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"], {\n      id: e.detail.id\n    }), document.getElementById(\"single_item_popup\"));\n  }\n});\n\n//# sourceURL=webpack:///./src/singlecourse/index.js?");

/***/ })

/******/ });