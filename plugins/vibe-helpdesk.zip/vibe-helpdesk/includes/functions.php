<?php
/**
 * Functions
 *
 * @author      VibeThemes
 * @category    Admin
 * @package     VibeKb
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

