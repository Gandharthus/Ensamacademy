/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/groups/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./_sass/main.scss":
/*!*************************!*\
  !*** ./_sass/main.scss ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("// extracted by mini-css-extract-plugin\n\n//# sourceURL=webpack:///./_sass/main.scss?");

/***/ }),

/***/ "./src/files.js":
/*!**********************!*\
  !*** ./src/files.js ***!
  \**********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _showsearchoptions_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./showsearchoptions.js */ \"./src/showsearchoptions.js\");\nconst {\n  createElement,\n  render,\n  useState,\n  useEffect,\n  Fragment\n} = wp.element;\nconst API_URL = window.vibedrive ? window.vibedrive.apiUrl : 'http://localhost/wplms/wp-json/vibedrive/v1/drive/';\n\nconst {\n  select\n} = wp.data;\n\nconst VibeDriveFiles = props => {\n  // if group page\n  let group_id = 0;\n\n  if (props.type == 'groups' && props.item.hasOwnProperty('group') && props.item.group.hasOwnProperty('id')) {\n    group_id = props.item.group.id;\n  }\n\n  const user_id = select('vibebp').getUser().id;\n  const [files, setFiles] = useState([]);\n  const [args, setArgs] = useState({\n    'page': 1,\n    'search': '',\n    scope: 'personal'\n  });\n  const [message, setMessage] = useState('');\n  const [showSharing, setshowSharing] = useState(false);\n  const [showEdit, setshowEdit] = useState(false);\n  const [name, setName] = useState('');\n  const [loading, setLoading] = useState({\n    isDeleting: false,\n    isEditing: false\n  });\n  useEffect(() => {//setArgs({ page: 1, search: '', scope: props.type });\n  }, []);\n  useEffect(() => {\n    (y => {\n      setFiles([]); // url making\n\n      let url = `${API_URL}/drive/${props.type}/${props.item.id}/get/${args.scope}/?security=${window.vibedrive.security}&search=${args.search}&page=${args.page}`;\n\n      if (group_id) {\n        url = `${API_URL}/drive/${props.type}/${props.item.id}/get/${args.scope}/?security=${window.vibedrive.security}&search=${args.search}&page=${args.page}&group_id=${group_id}`;\n      }\n\n      fetch(url, {\n        method: 'get'\n      }).then(res => res.json()).then(rreturn => {\n        if (rreturn && rreturn.status) {\n          if (rreturn.files.length) {\n            setFiles(rreturn.files);\n          }\n        }\n      });\n    })(files);\n  }, [args]);\n  useEffect(() => {\n    if (props.action === 'add') {\n      let $files = [...files];\n      $files.unshift(props.file);\n      setFiles($files);\n      dispatch('vibebp').addNotification({\n        icon: 'vicon vicon-check-box',\n        text: window.vibedrive.translations.fileAdded\n      });\n      setMessage(window.vibedrive.translations.fileAdded);\n    }\n  }, [props.file, props.action]);\n\n  const deleteFile = file_id => {\n    setLoading({ ...loading,\n      isDeleting: file_id\n    });\n    fetch(`${API_URL}/drive/delete/${file_id}/?security=${window.vibedrive.security}`, {\n      method: 'post',\n      body: JSON.stringify({\n        'user_id': props.item.id\n      })\n    }).then(res => res.json()).then(rreturn => {\n      setLoading({ ...loading,\n        isDeleting: false\n      });\n\n      if (rreturn.status) {\n        let newfiles = files.filter(item => {\n          return item.id !== file_id;\n        });\n\n        if (newfiles.length) {\n          setFiles(newfiles);\n        } else {\n          setFiles([]);\n        }\n\n        setMessage(rreturn.message);\n        setTimeout(() => {\n          setMessage('');\n        }, 3000);\n      }\n    });\n  };\n\n  const updateFile = file => {\n    let newFiles = [...files];\n    newFiles[newFiles.findIndex(f => {\n      return file.id === f.id;\n    })] = file;\n\n    if (!file.hasOwnProperty('change_sharing_option')) {\n      setshowSharing(false);\n    }\n\n    setFiles(newFiles);\n  };\n\n  const configureSharingOption = (scope, file_id) => {\n    let newFiles = [...files];\n    newFiles[newFiles.findIndex(file => {\n      return file.id === file_id;\n    })].change_sharing_option = scope;\n    setFiles(newFiles);\n  };\n\n  const handleEdit = file_id => {\n    setLoading({ ...loading,\n      isEditing: file_id\n    });\n    fetch(`${API_URL}/drive/edit/${file_id}/?security=${window.vibedrive.security}`, {\n      method: 'post',\n      body: JSON.stringify({\n        'user_id': props.item.id,\n        'name': name\n      })\n    }).then(res => res.json()).then(rreturn => {\n      setLoading({ ...loading,\n        isEditing: false\n      });\n\n      if (rreturn.status) {\n        //console.log(name);\n        let newFiles = [...files];\n        newFiles[newFiles.findIndex(file => {\n          return file.id === file_id;\n        })].name = name;\n        setFiles(newFiles);\n        console.log(newFiles); //rreturn.status = 'hiiii';\t\t\t\t\n      }\n    });\n  };\n\n  const can_edit = file_id => {\n    let i = files.findIndex(file => file.id == file_id);\n\n    if (i > -1) {\n      return files[i].author == user_id;\n    }\n\n    return false;\n  };\n\n  return createElement(Fragment, null, message.length ? createElement(\"div\", {\n    className: \"vbp_message\"\n  }, message) : '', createElement(\"div\", {\n    className: \"search_sorter\"\n  }, createElement(\"div\", {\n    className: \"searchbox\"\n  }, createElement(\"input\", {\n    type: \"text\",\n    className: \"searchFields\",\n    value: args.search,\n    placeholder: window.vibedrive.translations.placeholder,\n    onChange: e => {\n      let nargs = { ...args\n      };\n      nargs.search = e.target.value;\n      setArgs(nargs);\n    }\n  })), createElement(\"div\", {\n    className: \"order\"\n  }, createElement(\"select\", {\n    onChange: e => {\n      let nargs = { ...args\n      };\n      nargs.scope = e.target.value;\n      setArgs(nargs);\n    },\n    value: args.scope\n  }, Object.keys(window.vibedrive.settings.scopes).map(scope => {\n    if (group_id && scope == 'group') {\n      return '';\n    }\n\n    return createElement(\"option\", {\n      value: scope\n    }, window.vibedrive.settings.scopes[scope]);\n  })))), createElement(\"div\", {\n    className: \"record recordHeader\"\n  }, createElement(\"strong\", null, window.vibedrive.translations.file_name), createElement(\"strong\", null, window.vibedrive.translations.file_size), createElement(\"strong\", null, window.vibedrive.translations.file_access), createElement(\"strong\", null, window.vibedrive.translations.file_action)), Array.isArray(files) && files.length ? files.map(file => {\n    let classn = 'file ' + file.type;\n    return createElement(\"div\", {\n      className: classn\n    }, createElement(\"div\", {\n      className: \"vibedrive_name_conatiner\"\n    }, createElement(\"span\", {\n      className: file.type + ' type_view'\n    }, window.vibedrive.settings.scopes[file.type]), createElement(\"a\", {\n      className: \"file_url\",\n      href: file.url,\n      target: \"_blank\"\n    }, createElement(\"span\", {\n      className: \"filename\"\n    }, file.name)), createElement(\"div\", {\n      className: \"vibedrive_edit_conatiner\"\n    }, showEdit ? createElement(\"a\", {\n      onClick: () => setshowEdit(false),\n      className: \"file_edit\"\n    }, createElement(\"i\", {\n      class: \"vicon vicon-close\"\n    })) : can_edit(file.id) ? createElement(\"a\", {\n      onClick: () => setshowEdit(file.id),\n      className: \"file_edit\"\n    }, createElement(\"i\", {\n      class: \"vicon vicon-pencil\"\n    })) : '', showEdit && showEdit === file.id ? createElement(\"div\", {\n      className: \"file_edit\"\n    }, createElement(\"form\", null, createElement(\"input\", {\n      type: \"text\",\n      className: \"edit_file_name\",\n      value: name,\n      onChange: e => setName(e.target.value)\n    }), name ? createElement(\"a\", {\n      onClick: () => handleEdit(file.id),\n      className: loading.isEditing == file.id ? 'button is-primary is-loading  vicon vicon-save actions' : 'button is-primary vicon vicon-save actions'\n    }) : '')) : '')), createElement(\"div\", {\n      className: \"vibedrive_filesize_conatiner\"\n    }, createElement(\"span\", {\n      className: \"filesize\"\n    }, file.size)), createElement(\"div\", {\n      className: \"vibedrive_share_conatiner\"\n    }, createElement(\"span\", {\n      className: \"type\"\n    }, window.vibedrive.settings.scopes[file.type], file.hasOwnProperty('shared_values') && file.shared_values && file.shared_values.length ? createElement(\"span\", null, \" ( \", file.shared_values.length, \" ) \") : ''), showSharing ? createElement(\"a\", {\n      onClick: () => setshowSharing(false),\n      className: \"file_share\"\n    }, createElement(\"i\", {\n      class: \"vicon vicon-close\"\n    })) : can_edit(file.id) ? createElement(\"a\", {\n      onClick: () => setshowSharing(file.id),\n      className: \"file_share\"\n    }, createElement(\"i\", {\n      class: \"vicon vicon-share\"\n    })) : '', showSharing && showSharing === file.id ? createElement(\"div\", {\n      className: \"file_sharing\"\n    }, createElement(\"select\", {\n      onChange: e => configureSharingOption(e.target.value, file.id)\n    }, createElement(\"option\", null, window.vibedrive.translations.select_scope), Object.keys(window.vibedrive.settings.scopes).map(scope => {\n      if (scope !== 'personal') {\n        return createElement(\"option\", {\n          value: scope\n        }, window.vibedrive.settings.scopes[scope]);\n      }\n    })), file.hasOwnProperty('change_sharing_option') ? createElement(_showsearchoptions_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"], {\n      file: file,\n      onUpdate: file => updateFile(file)\n    }) : '') : ''), can_edit(file.id) ? createElement(\"span\", {\n      className: \"actions\"\n    }, createElement(\"a\", {\n      onClick: () => deleteFile(file.id),\n      className: loading.isDeleting == file.id ? 'button is-primary is-loading vicon vicon-trash actions ' : 'button is-primary vicon vicon-trash actions'\n    })) : '');\n  }) : createElement(\"div\", {\n    className: \"vbp_message\"\n  }, window.vibedrive.translations.no_files));\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (VibeDriveFiles);\n\n//# sourceURL=webpack:///./src/files.js?");

/***/ }),

/***/ "./src/groups/index.js":
/*!*****************************!*\
  !*** ./src/groups/index.js ***!
  \*****************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _uploader_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../uploader.js */ \"./src/uploader.js\");\n/* harmony import */ var _files_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../files.js */ \"./src/files.js\");\n/* harmony import */ var _sass_main_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../_sass/main.scss */ \"./_sass/main.scss\");\n/* harmony import */ var _sass_main_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_sass_main_scss__WEBPACK_IMPORTED_MODULE_2__);\nconst {\n  createElement,\n  render,\n  useState,\n  useEffect,\n  Fragment\n} = wp.element;\nconst {\n  dispatch,\n  select\n} = wp.data;\n\n\n\n\nconst VibeDrive = props => {\n  const user_id = select('vibebp').getUser().id;\n  const [file, setFile] = useState({});\n  const [action, setAction] = useState('');\n\n  const setUpdate = ($file, $action) => {\n    setFile($file);\n    setAction($action);\n  };\n\n  const [item, setItem] = useState({ ...props.item\n  });\n  useEffect(() => {\n    if (!props.item.hasOwnProperty('id')) {\n      setItem({ ...item,\n        id: user_id\n      });\n    }\n  }, [props]);\n  return props.type && item.id ? createElement(Fragment, null, createElement(_uploader_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"], {\n    type: props.type,\n    update: setUpdate,\n    item: item\n  }), createElement(_files_js__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n    type: props.type,\n    file: file,\n    action: action,\n    item: item\n  })) : '';\n};\n\ndocument.addEventListener('group_tab', e => {\n  if (e.detail.tab === 'vibedrive_group_drive') {\n    console.log(e.detail.group);\n    let group = e.detail.group;\n    render(createElement(VibeDrive, {\n      type: \"groups\",\n      item: {\n        group: group\n      }\n    }), document.querySelector(\"#vibedrive_group_drive\"));\n  }\n});\n\n//# sourceURL=webpack:///./src/groups/index.js?");

/***/ }),

/***/ "./src/showsearchoptions.js":
/*!**********************************!*\
  !*** ./src/showsearchoptions.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\nconst {\n  createElement,\n  render,\n  useState,\n  useEffect,\n  Fragment\n} = wp.element;\nconst API_URL = window.vibedrive ? window.vibedrive.apiUrl : 'http://localhost/wplms/wp-json/vibedrive/v1/drive/';\nconst {\n  select\n} = wp.data;\n\nconst ShowsearchOptions = props => {\n  const user_id = select('vibebp').getUser().id;\n  const [message, setMessage] = useState('');\n  const [search, setSearch] = useState('');\n  const [searchResults, setsearchResults] = useState([]);\n  const [inDebounce, setinDebounce] = useState(false);\n  const [loading, setLoading] = useState({\n    isSaving: false\n  });\n  useEffect(() => {\n    let newFile = { ...props.file\n    };\n    console.log(props.file);\n\n    if (props.file.hasOwnProperty('shared_values') && props.file.shared_values && props.file.shared_values.length) {\n      fetch(`${API_URL}/drive/file/${props.file.id}/${props.file.type}/?ids=${JSON.stringify(props.file.shared_values)}&security=${window.vibedrive.security}`, {\n        method: 'get'\n      }).then(res => res.json()).then(rreturn => {\n        newFile.shared_values = rreturn;\n        props.onUpdate(newFile);\n      });\n    }\n  }, []);\n\n  const apiCall = () => {\n    setLoading({ ...loading,\n      isSaving: true\n    });\n    fetch(`${API_URL}/drive/search/${props.file.change_sharing_option}/?s=${search}&security=${window.vibedrive.security}`, {\n      method: 'get'\n    }).then(res => res.json()).then(rreturn => {\n      setLoading({ ...loading,\n        isSaving: false\n      });\n\n      if (rreturn.status) {\n        if (rreturn.values.length) {\n          setsearchResults(rreturn.values);\n        }\n      } else {\n        setMessage(rreturn.message);\n        setTimeout(() => {\n          setMessage('');\n        }, 3000);\n      }\n    });\n  };\n\n  useEffect(() => {\n    if (search.length > 3) {\n      apiCall();\n    }\n  }, [search]);\n\n  const saveApiCall = () => {\n    setLoading({ ...loading,\n      isSaving: true\n    });\n    fetch(`${API_URL}/drive/save/${props.file.id}/?security=${window.vibedrive.security}`, {\n      method: 'post',\n      body: JSON.stringify({\n        'user_id': user_id,\n        'file': props.file\n      })\n    }).then(res => res.json()).then(rreturn => {\n      setLoading({ ...loading,\n        isSaving: false\n      });\n\n      if (rreturn.status) {\n        let newfile = { ...props.file\n        };\n        console.log('removing change option');\n        newfile.type = newfile.change_sharing_option;\n        delete newfile.change_sharing_option;\n        console.log(newfile);\n        props.onUpdate(newfile);\n      }\n    });\n  };\n\n  const updateProps = (type, item) => {\n    let newFile = { ...props.file\n    };\n\n    if (type === 'remove') {\n      let index = newFile.shared_values.findIndex(i => {\n        return i.id === item.id;\n      });\n\n      if (index > -1) {\n        newFile.shared_values.splice(index, 1);\n      }\n\n      props.onUpdate(newFile);\n    }\n\n    if (type === 'add') {\n      if (!newFile.hasOwnProperty('shared_values') || !newFile.shared_values) {\n        newFile['shared_values'] = [];\n      }\n\n      newFile.shared_values.push(item);\n      props.onUpdate(newFile);\n    }\n  };\n\n  let newSearchResults = [...searchResults];\n\n  if (searchResults.length && props.file.hasOwnProperty('shared_values') && Array.isArray(props.file.shared_values)) {\n    newSearchResults = searchResults.filter(item => {\n      return props.file.shared_values.indexOf(item) === -1;\n    });\n  }\n\n  return createElement(\"div\", null, props.file.hasOwnProperty('shared_values') && Array.isArray(props.file.shared_values) && props.file.shared_values.length ? createElement(\"ul\", {\n    className: \"selected\"\n  }, props.file.shared_values.map(item => {\n    return createElement(\"li\", null, item.label, \" \", createElement(\"a\", {\n      className: \"fa fa-close\",\n      onClick: () => updateProps('remove', item)\n    }));\n  })) : '', createElement(\"div\", {\n    className: \"searchValues\"\n  }, createElement(\"input\", {\n    type: \"text\",\n    value: search,\n    onChange: e => setSearch(e.target.value)\n  }), createElement(\"a\", {\n    className: loading.isSaving ? 'button is-primary is-loading vicon vicon-share actions ' : 'button is-primary vicon vicon-share actions',\n    onClick: saveApiCall\n  })), newSearchResults.length ? createElement(\"ul\", null, newSearchResults.map(item => {\n    return createElement(\"li\", {\n      onClick: () => updateProps('add', item)\n    }, item.label);\n  })) : '', message.length ? createElement(\"div\", {\n    className: \"message\"\n  }, message) : '');\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (ShowsearchOptions);\n\n//# sourceURL=webpack:///./src/showsearchoptions.js?");

/***/ }),

/***/ "./src/uploader.js":
/*!*************************!*\
  !*** ./src/uploader.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\nconst {\n  createElement,\n  render,\n  useState,\n  useEffect,\n  Fragment\n} = wp.element;\nconst API_URL = window.vibedrive ? window.vibedrive.apiUrl : 'http://localhost/wplms/wp-json/vibedrive/v1/drive/';\n\nconst VibeDriveUploader = props => {\n  let scp = Object.keys(window.vibedrive.settings.scopes)[0]; // if group page\n\n  let group_id = 0;\n\n  if (props.type == 'groups' && props.item.hasOwnProperty('group') && props.item.group.hasOwnProperty('id')) {\n    group_id = props.item.group.id;\n    scp = Object.keys(window.vibedrive.settings.scopes)[2];\n  }\n\n  const [scope, setScope] = useState(scp);\n  const [file, setFile] = useState('');\n  const [fileDetails, setfileDetails] = useState('file_details');\n  const [fileUpload, setfileUpload] = useState(window.vibedrive.translations.file_upload);\n  const [loading, setLoading] = useState({\n    isUploading: false\n  });\n\n  const unsetFile = () => {\n    setFile('');\n  };\n\n  const setuploadFile = e => {\n    setFile(e.target.files[0]);\n  };\n\n  const fileUploadfx = () => {\n    setLoading({ ...loading,\n      isUploading: true\n    });\n    let body_form_data = new FormData();\n    body_form_data.append('file', file); // url making\n\n    let url = `${API_URL}/drive/user/${scope}/${props.item.id}/upload_file/?security=${window.vibedrive.security}`;\n\n    if (group_id) {\n      url = `${API_URL}/drive/user/${scope}/${props.item.id}/upload_file/?security=${window.vibedrive.security}&group_id=${group_id}`;\n    }\n\n    fetch(url, {\n      method: 'post',\n      body: body_form_data\n    }).then(res => res.json()).then(rreturn => {\n      setLoading({ ...loading,\n        isUploading: false\n      });\n      debugger;\n\n      if (rreturn.status) {\n        let details = [...fileDetails];\n        details.push({\n          'meta_key': 'uploaded_file',\n          'meta_value': rreturn.file_url\n        });\n        setfileDetails(details);\n        props.update(rreturn.file, 'add');\n      } else {\n        dispatch('vibebp').addNotification({\n          text: rreturn.message\n        });\n      }\n\n      dispatch('vibebp').addNotification({\n        text: rreturn.message\n      });\n      setfileUpload(rreturn.message);\n      setTimeout(() => {\n        setfileUpload(window.vibedrive.translations.file_upload);\n      }, 3000);\n    });\n  };\n\n  return createElement(Fragment, null, file ? createElement(\"div\", {\n    className: \"upload_area\"\n  }, createElement(\"span\", {\n    className: \"uploaded_file\"\n  }, file.name), createElement(\"a\", {\n    className: \"vicon vicon-close\",\n    onClick: unsetFile\n  })) : createElement(\"div\", {\n    className: \"upload_area\"\n  }, createElement(\"input\", {\n    type: \"file\",\n    onChange: setuploadFile,\n    name: \"file\",\n    value: file\n  })), createElement(\"div\", {\n    className: \"upload_options\"\n  }, createElement(\"select\", {\n    onChange: e => setScope(e.target.value)\n  }, Object.keys(window.vibedrive.settings.scopes).map(scope => {\n    return createElement(\"option\", {\n      value: scope\n    }, window.vibedrive.settings.scopes[scope]);\n  })), createElement(\"a\", {\n    onClick: fileUploadfx,\n    className: loading.isUploading ? 'button is-primary is-loading vicon vicon-upload actions ' : 'button is-primary vicon vicon-upload actions'\n  })));\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (VibeDriveUploader);\n\n//# sourceURL=webpack:///./src/uploader.js?");

/***/ })

/******/ });