/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/sales_stats/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./_sass/sales_stats.scss":
/*!********************************!*\
  !*** ./_sass/sales_stats.scss ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("// extracted by mini-css-extract-plugin\n\n//# sourceURL=webpack:///./_sass/sales_stats.scss?");

/***/ }),

/***/ "./src/functions.js":
/*!**************************!*\
  !*** ./src/functions.js ***!
  \**************************/
/*! exports provided: default, useThrottledEffect, validateUrl, IsJsonString, compareThis, debounce */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"useThrottledEffect\", function() { return useThrottledEffect; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"validateUrl\", function() { return validateUrl; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"IsJsonString\", function() { return IsJsonString; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"compareThis\", function() { return compareThis; });\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"debounce\", function() { return debounce; });\nconst {\n  createElement,\n  useState,\n  useEffect,\n  Fragment,\n  render,\n  useRef\n} = wp.element;\nconst {\n  dispatch,\n  select\n} = wp.data;\n\nconst Avatar = props => {\n  const [avatar, setAvatar] = useState('');\n  useEffect(() => {\n    let key = '';\n    let type = '';\n    let ids = {};\n\n    switch (props.type) {\n      case 'friends':\n        type = 'user';\n        key = props.id.item_id;\n        break;\n\n      case 'group':\n        // custom changes\n        type = 'group';\n        key = props.id.id;\n        ids = {\n          item_id: props.id.id\n        };\n        break;\n\n      case 'activity':\n        type = 'user';\n        key = props.id.secondary_item_id;\n        break;\n\n      case 'user':\n        type = 'user';\n        key = props.id.id;\n        ids = {\n          user_id: props.id.id\n        };\n        break;\n\n      case 'shared':\n        //custom changes\n        type = 'user';\n        key = props.id.id;\n        ids = {\n          user_id: props.id.id\n        };\n        break;\n\n      case 'course':\n        //custom changes\n        type = 'course';\n        key = props.id.id;\n        ids = {\n          item_id: props.id.id\n        };\n        break;\n\n      default:\n        type = props.type;\n        key = props.id.id;\n        break;\n    }\n\n    localforage.getItem(type + '_' + key).then(stored => {\n      if (stored !== null) {\n        setAvatar(JSON.parse(stored));\n      } else {\n        fetch(`${window.vibebp.api.url}/avatar`, {\n          method: 'post',\n          body: JSON.stringify({\n            type: type,\n            ids: ids,\n            token: select('vibebp').getToken()\n          })\n        }).then(res => res.json()).then(data => {\n          if (data.status) {\n            let temp = { ...data.value,\n              id: props.id.id\n            };\n            localforage.setItem(data.key, JSON.stringify(temp));\n            setAvatar(temp);\n          }\n        });\n      }\n    });\n  }, [props.id]);\n  return createElement(Fragment, null, props.not_show_name ? createElement(\"img\", {\n    src: avatar.avatar,\n    className: \"vibebp_avatar\",\n    onClick: props.click,\n    alt: avatar.name,\n    title: avatar.name\n  }) : createElement(\"span\", null, createElement(\"img\", {\n    src: avatar.avatar,\n    className: \"vibebp_avatar\",\n    onClick: props.click,\n    alt: avatar.name,\n    title: avatar.name\n  }), createElement(\"span\", {\n    className: \"avname\"\n  }, avatar.name)));\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (Avatar);\nconst useThrottledEffect = (callback, delay, deps = []) => {\n  const lastRan = useRef(Date.now());\n  useEffect(() => {\n    const handler = setTimeout(function () {\n      if (Date.now() - lastRan.current >= delay) {\n        callback();\n        lastRan.current = Date.now();\n      }\n    }, delay - (Date.now() - lastRan.current));\n    return () => {\n      clearTimeout(handler);\n    };\n  }, [delay, ...deps]);\n};\nconst validateUrl = value => {\n  return /^(?:(?:(?:https?|ftp):)?\\/\\/)(?:\\S+(?::\\S*)?@)?(?:(?!(?:10|127)(?:\\.\\d{1,3}){3})(?!(?:169\\.254|192\\.168)(?:\\.\\d{1,3}){2})(?!172\\.(?:1[6-9]|2\\d|3[0-1])(?:\\.\\d{1,3}){2})(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))(?::\\d{2,5})?(?:[/?#]\\S*)?$/i.test(value);\n};\nconst IsJsonString = str => {\n  try {\n    JSON.parse(str);\n  } catch (e) {\n    return false;\n  }\n\n  return true;\n};\nconst compareThis = (vars, array) => {\n  let flag = false;\n  if (!Array.isArray(array)) return false;\n\n  if (Array.isArray(vars)) {\n    array.map(item => {\n      if (vars.indexOf(item) > -1) {\n        flag = true;\n      }\n    });\n  } else {\n    Object.keys(vars).map(item => {\n      if (array.indexOf(item) > -1) {\n        flag = true;\n      }\n    });\n  }\n\n  return flag;\n};\nconst debounce = (func, wait, immediate) => {\n  var timeout;\n  return function () {\n    var context = this,\n        args = arguments;\n\n    var later = function () {\n      timeout = null;\n\n      if (!immediate) {\n        func.apply(context, args);\n      }\n    };\n\n    var callNow = immediate && !timeout;\n    clearTimeout(timeout);\n    timeout = setTimeout(later, wait || 200);\n\n    if (callNow) {\n      func.apply(context, args);\n    }\n  };\n};\n\n//# sourceURL=webpack:///./src/functions.js?");

/***/ }),

/***/ "./src/sales_stats/index.js":
/*!**********************************!*\
  !*** ./src/sales_stats/index.js ***!
  \**********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../functions */ \"./src/functions.js\");\n/* harmony import */ var _sass_sales_stats_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../_sass/sales_stats.scss */ \"./_sass/sales_stats.scss\");\n/* harmony import */ var _sass_sales_stats_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sass_sales_stats_scss__WEBPACK_IMPORTED_MODULE_1__);\nconst {\n  createElement,\n  render,\n  useState,\n  useEffect,\n  Fragment\n} = wp.element;\nconst {\n  select,\n  dispatch\n} = wp.data;\n\n\n\nconst SalesStats = props => {\n  const localize = window.sales_stats_widget;\n  const [isLoading, setIsLoading] = useState(true);\n  const [data, setData] = useState({});\n  var d = new Date();\n  d.setMonth(d.getMonth() - 1);\n  const [args, setArgs] = useState({\n    start: d.getTime(),\n    end: new Date().getTime()\n  }); // start one month bofore current\n\n  useEffect(() => {\n    if (args.start && args.end && args.start <= args.end) {\n      setIsLoading(true);\n      fetch(`${localize.api}/sales_stats`, {\n        method: 'post',\n        body: JSON.stringify({\n          token: select('vibebp').getToken(),\n          args: args\n        })\n      }).then(res => res.json()).then(rreturn => {\n        setIsLoading(false);\n\n        if (rreturn.status) {\n          setData(rreturn.data);\n        }\n      });\n    }\n  }, [args]);\n  return createElement(\"div\", {\n    className: \"sales_stats_widget\"\n  }, createElement(\"div\", {\n    className: \"sales_stats_header\"\n  }, createElement(\"div\", {\n    className: \"vibebp_form_field\"\n  }, createElement(\"label\", null, localize.translations.from), createElement(\"input\", {\n    type: \"text\",\n    ref: ref => {\n      if (ref) {\n        flatpickr(ref, {\n          altInput: true,\n          defaultDate: args.start,\n          enableTime: true,\n          onChange: (selectedDay, dateStr, instance) => {\n            let nargs = { ...args\n            };\n            nargs.start = new Date(dateStr).getTime();\n            setArgs(nargs);\n          }\n        });\n      }\n    }\n  })), createElement(\"div\", {\n    className: \"vibebp_form_field\"\n  }, createElement(\"label\", null, localize.translations.to), createElement(\"input\", {\n    type: \"text\",\n    ref: ref => {\n      if (ref) {\n        flatpickr(ref, {\n          altInput: true,\n          defaultDate: args.end,\n          enableTime: true,\n          onChange: (selectedDay, dateStr, instance) => {\n            let nargs = { ...args\n            };\n            nargs.end = new Date(dateStr).getTime();\n            setArgs(nargs);\n          }\n        });\n      }\n    }\n  }))), isLoading ? createElement(\"div\", null, createElement(\"div\", {\n    className: \"widget_loader\"\n  }, createElement(\"div\", null), createElement(\"div\", null), createElement(\"div\", null), createElement(\"div\", null))) : createElement(Fragment, null, data && Object.keys(data) && Object.keys(data).length ? createElement(\"div\", {\n    className: \"sales_stats_data\"\n  }, Object.keys(data).map(key => {\n    if (!data[key]) {\n      data[key] = localize.translations['no_data_found'];\n    }\n\n    if (key == 'total_instructors_commission') {\n      if (Array.isArray(data[key]) && data[key].length) {\n        return createElement(\"div\", null, createElement(\"div\", null, localize.translations[key]), createElement(\"div\", null, data[key].map(d => {\n          return createElement(\"div\", {\n            className: \"multi\"\n          }, d.value + ' ' + d.currency);\n        })));\n      } else {\n        data[key] = localize.translations['no_data_found'];\n      }\n    } else if (key == 'most_earning_by_instructor') {\n      if (Array.isArray(data[key]) && data[key].length) {\n        return createElement(\"div\", null, createElement(\"div\", null, localize.translations[key]), createElement(\"div\", null, data[key].map(d => {\n          return createElement(\"div\", null, createElement(\"span\", {\n            className: \"multi\"\n          }, d.value.value + ' ' + d.currency), createElement(\"span\", null, createElement(_functions__WEBPACK_IMPORTED_MODULE_0__[\"default\"], {\n            type: \"user\",\n            id: {\n              id: parseInt(d.value.user_id)\n            }\n          })));\n        })));\n      } else {\n        data[key] = localize.translations['no_data_found'];\n      }\n    } else if (key == 'most_sold_course') {\n      if (data[key] && data[key].hasOwnProperty('count')) {\n        return createElement(\"div\", null, createElement(\"div\", null, localize.translations[key]), createElement(\"div\", null, createElement(\"span\", {\n          className: \"multi\"\n        }, data[key]['count'] + ' ' + localize.translations['times']), createElement(\"span\", null, createElement(\"a\", {\n          href: data[key]['url'],\n          target: \"_blank\"\n        }, createElement(_functions__WEBPACK_IMPORTED_MODULE_0__[\"default\"], {\n          type: \"course\",\n          id: {\n            id: parseInt(data[key]['course_id'])\n          }\n        })))));\n      } else {\n        data[key] = localize.translations['no_data_found'];\n      }\n    }\n\n    return createElement(\"div\", null, createElement(\"div\", null, localize.translations[key]), createElement(\"div\", {\n      dangerouslySetInnerHTML: {\n        __html: data[key]\n      }\n    }));\n  })) : ''));\n};\n\ndocument.addEventListener(\"sales_stats_widget\", e => {\n  //e.target.removeEventListener(e.type, arguments.callee);\n  document.querySelectorAll('.sales_stats_widget').forEach(el => {\n    render(createElement(SalesStats, {\n      settings: e.detail.widget.options\n    }), el);\n  });\n});\n\n//# sourceURL=webpack:///./src/sales_stats/index.js?");

/***/ })

/******/ });