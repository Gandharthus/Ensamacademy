<?php
/**
 * Initialise WPLMS Zoom
 *
 * @class       Wplms_Zoom_Actions
 * @author      VibeThemes
 * @category    Admin
 * @package     WPLMS-Zoom/classes
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}



/*  
    Note: update_post_meta(post_id,'mutlihostkey',key)
    if(key) then fetch key-secret from get_option('multi_zoom_credential) and send obj
    else admin obj
    use:Object create
*/
function get_zoom_api_object($k){
    $vibe_zoom_api_init  = null;
    if($k){
        $multi_zoom_credential = get_option('multi_zoom_credential');
        if(!is_array($multi_zoom_credential)){
            $multi_zoom_credential = array();
        }
        foreach ($multi_zoom_credential as $key => $value) {
            if($value['key'] == $k && ($value['api_key']  && $value['api_secret'])){
                $vibe_zoom_api_init = new Vibe_Zoom_Video_Conferencing_Api($value['api_key'],$value['api_secret']);
            break;
            }
        }
    }else{
        $vibe_zoom_api_init = vibe_zoom_api_init();
    }
    return $vibe_zoom_api_init;
}